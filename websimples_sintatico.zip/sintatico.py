from lexer import obter_tokens, find_column

SYNTAX_KEYWORDS = {'TITULO', 'TEXTO', 'BOTAO', 'COR', 'IMAGEM', 'LINK', 'SECAO'}


class ParseError(Exception):
    pass


class SintaticoParser:
    def __init__(self, codigo, tokens):
        self.codigo = codigo
        self.tokens = [tok for tok in tokens if tok.type != 'COMENTARIO']
        self.pos = 0
        self.errors = []

    def current_token(self):
        return self.tokens[self.pos] if self.pos < len(self.tokens) else None

    def advance(self):
        token = self.current_token()
        self.pos += 1
        return token

    def is_at_end(self):
        return self.current_token() is None

    def error(self, token, message):
        if token is None:
            line = self.codigo.count('\n') + 1
            col = 1
            self.errors.append(f"Linha: {line} - Coluna {col} - ERRO SINTÁTICO: {message}")
        else:
            col = find_column(self.codigo, token)
            self.errors.append(f"Linha: {token.lineno} - Coluna {col} - ERRO SINTÁTICO: {message}")

    def expect(self, token_type, message):
        token = self.current_token()
        if token is None:
            self.error(token, message)
            return None
        if token.type == token_type:
            return self.advance()
        self.error(token, message)
        return None

    def synchronize(self, sync_tokens=None):
        if sync_tokens is None:
            sync_tokens = set(SYNTAX_KEYWORDS) | {'PAGINA', 'FIM', 'FECHA_CHAVES'}
        while self.current_token() and self.current_token().type not in sync_tokens:
            self.advance()

    def parse(self):
        ast = {
            'type': 'program',
            'pagina': None,
            'statements': [],
            'fim': None
        }

        if self.current_token() and self.current_token().type == 'PAGINA':
            ast['pagina'] = self.advance().value
        else:
            self.error(self.current_token(), "Esperado a palavra reservada 'pagina' no início do programa.")
            self.synchronize({'PAGINA', 'ABRE_CHAVES'})
            if self.current_token() and self.current_token().type == 'PAGINA':
                ast['pagina'] = self.advance().value

        self.expect('ABRE_CHAVES', "Esperado '{' após a palavra reservada 'pagina'.")

        while self.current_token() and self.current_token().type not in {'FECHA_CHAVES', 'FIM'}:
            statement = self.parse_statement()
            if statement:
                ast['statements'].append(statement)

        self.expect('FECHA_CHAVES', "Esperado '}' para fechar o bloco da página.")
        if self.current_token() and self.current_token().type == 'FIM':
            ast['fim'] = self.advance().value
        else:
            self.error(self.current_token(), "Esperado a palavra reservada 'fim' após o bloco da página.")

        if self.current_token():
            token = self.current_token()
            self.error(token, f"Token inesperado após o fechamento do programa: '{token.value}'")

        return ast

    def parse_statement(self):
        token = self.current_token()
        if token is None:
            return None

        if token.type in SYNTAX_KEYWORDS:
            return self.parse_assignment()

        self.error(token, f"Esperado comando válido dentro do bloco da página, encontrado '{token.value}'.")
        self.synchronize()
        return None

    def parse_assignment(self):
        keyword_token = self.advance()
        self.expect('ATRIBUICAO', f"Esperado '=' após '{keyword_token.value}'.")

        value_token = self.current_token()
        if value_token and value_token.type in {'STRING', 'NUMERO'}:
            self.advance()
        else:
            self.error(value_token, "Esperado um valor do tipo STRING ou NUMERO após '='.")

        if self.current_token() and self.current_token().type == 'PONTO':
            self.advance()
        else:
            self.error(self.current_token(), "Esperado '.' ao final da instrução.")
            self.synchronize()

        return {
            'type': 'assignment',
            'keyword': keyword_token.type,
            'value': value_token.value if value_token else None,
            'line': keyword_token.lineno,
            'column': find_column(self.codigo, keyword_token)
        }

    def get_tree_text(self, node=None, level=0):
        if node is None:
            node = self.parse()

        indent = '  ' * level
        lines = []

        if node['type'] == 'program':
            lines.append(f"{indent}Programa")
            lines.append(f"{indent}  Bloco: pagina {{ ... }} fim")
            for statement in node['statements']:
                lines.append(self.get_tree_text(statement, level + 1))
        elif node['type'] == 'assignment':
            value = node['value'] if node['value'] is not None else '<<valor ausente>>'
            lines.append(f"{indent}{node['keyword']} = {value}")
        else:
            lines.append(f"{indent}{node}")

        return '\n'.join(lines)


def analisar_sintatico(codigo):
    tokens, lex_errors = obter_tokens(codigo)
    parser = SintaticoParser(codigo, tokens)
    ast = parser.parse()
    return ast, parser.errors, lex_errors
